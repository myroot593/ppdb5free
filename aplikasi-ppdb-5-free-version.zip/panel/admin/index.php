<?php
    session_start();
    require_once '../core/session.php';
    require_once '../../config/database.php';    
    require_once '../core/function.php';
    if(AdministratorCek()):
        die("error");
    else:
        UserAktif(); 
        $admin_uid=$DataUser[0];
        $admin_username=$DataUser[1];
        $admin_email=$DataUser[2];
        $admin_nama=$DataUser[3];
        $admin_role=$DataUser[4];
        $admin_foto=$DataUser[5]; 


       
    endif;
    $AdminData=AdminData($admin_uid);
    $Admin_row=$AdminData->fetch_array();
    $AdminData->free_result();
?>

<?php
head();
css();
SidebarMenu($Admin_row, $admin_nama);
HeaderMenu();

?>

<?php if(!isset($_GET['page'])){$_GET['page']='';}?>

<?php if($_GET['page']=='dashboard'){ ?>
            <?php 
                $Dashboard=Dashboard();
                $DashboardData=$Dashboard->fetch_array();
                $JumlahGender=JumlahGender($DashboardData['jml_pria'], $DashboardData['jml_wanita']);    
                $PersentasePria=NilaiPersen($DashboardData['jml_pria'], $JumlahGender);
                $PersentaseWanita=NilaiPersen($DashboardData['jml_wanita'], $JumlahGender);               
               
            ?>
            <section class="au-breadcrumb m-t-75">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="au-breadcrumb-content">
                                    <div class="au-breadcrumb-left">
                                        <span class="au-breadcrumb-span">You are here:</span>
                                        <ul class="list-unstyled list-inline au-breadcrumb__list">
                                            <li class="list-inline-item active">
                                                <a href="?page=dashboard">Home</a>
                                            </li>
                                            <li class="list-inline-item seprate">
                                                <span>/</span>
                                            </li>
                                            <li class="list-inline-item">Dashboard</li>
                                        </ul>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END BREADCRUMB-->

             <!-- STATISTIC-->
            <section class="statistic">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                                               <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">overview</h2>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-25">
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo JumlahPendaftar(); ?></h2>
                                                <span>Pendaftar</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c2">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_verifikasi']; ?></h2>
                                                <span>Belum Diverifikasi</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c3">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_terverifikasi']; ?></h2>
                                                <span>Terverifikasi</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c3">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_diterima']; ?></h2>
                                                <span>Diterima</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c4">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_ditolak']; ?></h2>
                                                <span>Ditolak</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart4"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END STATISTIC-->
            <section>
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-6">
                                <!-- RECENT REPORT 2-->
                                <div class="au-card chart-percent-card">
                                    <div class="au-card-inner">
                                        <h5 class="title-2 tm-b-5">Presentase</h5>
                                        <em class="small">Presentase pendaftar berdasarkan jenis kelamin</em>
                                        <div class="row no-gutters">
                                            <div class="col-xl-6">
                                                <div class="chart-note-wrap">
                                                    <div class="chart-note mr-0 d-block">
                                                        <span class="dot dot--blue"></span>
                                                        <span>pria <?php echo $PersentasePria; ?></span>
                                                    </div>
                                                    <div class="chart-note mr-0 d-block">
                                                        <span class="dot dot--red"></span>
                                                        <span>wanita <?php echo $PersentaseWanita; ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="percent-chart">
                                                    <canvas id="percent-chart93"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="top-campaign">
                                    <h3 class="title-3 m-b-30">data masuk</h3>
                                       <em class="small">Data masuk terakhir yang belum diverifikasi</em>
                                       <div class="table-responsive">
                                         <?php 
                                             $DataMasuk=DataMasuk();
                                             $row=$DataMasuk->fetch_array();
                                                $id_p=$row['id'];
                                                $nama_p=$row['nama'];
                                                $nomor_pendaftaran_p=$row['nomor_pendaftaran'];
                                                $status_pendaftaran_p=$row['status_pendaftaran'];
                                           
                                             $DataMasuk->free_result();   
                                        ?> 
                                         <table class="table">
                                            <tr>
                                                <td>No. Pendft</td>
                                                <td><?php echo $nomor_pendaftaran_p; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Nama</td>
                                                <td><?php echo $nama_p; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Status Pendaft</td>
                                                <td><?php echo $status_pendaftaran_p; ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><a href=?page=verifikasi-data&id=<?php echo $id_p;?>>Verifikasi</td>
                                                
                                            </tr>
                                        </table>   
                                       </div>
                                       
                                       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                                <!-- END RECENT REPORT 2             -->
<?php }elseif($_GET['page']=='informasi'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Informasi</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </section>
            <?php LoadInformasi(); ?>
<?php }elseif($_GET['page']=='informasi-tambah'){ ?>
     <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Tambah Informasi</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </section> 
        <?php LoadInformasiTambah(); ?>    
<?php }elseif($_GET['page']=='informasi-edit'){ ?>
  <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Edit Informasi</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
        </section> 
        <?php
            if(!LoadInformasiEdit(trim($_GET['id']))){
                echo'
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-danger alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>

                ';

            }else{
                LoadInformasiUpdate();
            }

        ?>  
<?php }elseif($_GET['page']=='informasi-delete'){ ?>
    <?php
            if(!LoadInformasiEdit(trim($_GET['id']))){
                echo'
                <div class="container-fluid">
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-danger alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>
                </div>
                ';

            }else{
                
                Load_DeleteInfo();
                
            }

        ?>  
<?php }elseif($_GET['page']=='data-pendaftar-semua'){ ?> 
		<section class="au-breadcrumb m-t-75">
		                <div class="section__content section__content--p30">
		                    <div class="container-fluid">
		                        <div class="row">
		                            <div class="col-md-12">
		                                <div class="au-breadcrumb-content">
		                                    <div class="au-breadcrumb-left">
		                                        <span class="au-breadcrumb-span">You are here:</span>
		                                        <ul class="list-unstyled list-inline au-breadcrumb__list">
		                                            <li class="list-inline-item active">
		                                                <a href="?page=dashboard">Home</a>
		                                            </li>
		                                            <li class="list-inline-item seprate">
		                                                <span>/</span>
		                                            </li>
		                                            <li class="list-inline-item">Data Pendaftar</li>
		                                        </ul>
		                                    </div>
		                                   
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		 </section>           
		 <?php Pendaftar(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar-bverifikasi'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Data Pendaftar / Belum Diverifikasi</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section>  
         <?php PendaftarBelumVerifikasi(); ?>
<?php }elseif($_GET['page']=='data-pendaftar-terverifikasi'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Data Pendaftar / Terverifikasi</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section>  
         <?php PendaftarTerverifikasi(); ?>  
<?php }elseif($_GET['page']=='data-pendaftar-diterima'){ ?>
        <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                            <li class="list-inline-item">Data Pendaftar / Diterima </li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section>  
         <?php PendaftarDiterima(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar-ditolak'){ ?>
     <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Data Pendaftar / Ditolak </li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section>  
         <?php PendaftarDitolak(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar'){ ?>
         <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Data Pendaftar</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section> 
         <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
         }else{
            LoadDataPendaftar();
         } 

         ?>
<?php }elseif($_GET['page']=='data-pendaftar-delete'){ ?>
    <?php
     if(!DataPendaftarDetail($_GET['id'])){
             echo'
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>

                ';
        }else{
            PendaftarDelete_load();
        }   


    ?>
<?php }elseif($_GET['page']=='pembayaran'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Data Pembayaran </li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section>  
         <?php Pembayaran(); ?> 
<?php }elseif($_GET['page']=='verifikasi-data'){ ?>
     <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Verifikasi Data</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
         </section>
         <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
            }else{
                LoadVerifikasiPendaftar();
            }
        ?>  
<?php }elseif($_GET['page']=='verifikasi-pembayaran'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Verifikasi Pembayaran</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
     <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert au-alert-danger alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
            }else{
                LoadVerifikasiPembayaran();
            }
        ?>  
<?php }elseif($_GET['page']=='panitia'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Panita</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php PanitiaLoad(); ?>
<?php }elseif($_GET['page']=='panitia-tambah'){ ?>
    <?php
    $username_err = $password_err = $confir_password_err = $nama_err = $email_err = $role_err = $foto_panitia_err = $simpan = "";
        if(isset($_POST['tambah_panitia'])){
            if(empty(trim($_POST['username']))){
                $username_err="Username Panitia tidak boleh kosong";
            }elseif(ValidateName($_POST['username'])){
                $username_err="Username hanya boleh karakter alphabet";
            }else{
                if(CekUsername($_POST['username'])){
                    $username_err="Maaf username tersebut sudah digunakan";
                }else{
                    $username=test_input($_POST['username']);
                }
            }
            if(empty(trim($_POST['password']))){
                $password_err="Password tidak boleh kosong";
            }elseif(strlen($_POST['password'])<6){
                $password_err="Password tidak boleh kurang dari 6 karakater";
            }else{
                $password=trim($_POST['password']);
            }
            if(empty(trim($_POST['confir_password']))){
                $confir_password_err="Konfirmasi passwird tidak boleh kosong";
            }else{
                $confir_password=trim($_POST['confir_password']);
                if(empty($password_err)&& ($password!=$confir_password)){
                    $confir_password_err="Konfirmasi password tidak cocok";
                }
            }
            if(empty(trim($_POST['email']))){
                $email_err="Email tidak boleh kosong";
            }elseif(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
                $email_err="Format penulisan email salah";
            }else{
                if(CekEmail($_POST['email'])){
                    $email_err="Maaf email tersebut sudah digunakan";
                }else{
                    $email=test_input($_POST['email']);
                    $email=EscapeString($email);
                }
            }
            if(empty($_POST['nama'])){
                $nama_err="Nama lengkap panitia tidak boleh kosong";
            }else{
                $nama=test_input($_POST['nama']);
                $nama=EscapeString($nama);
            }
            if(empty($_POST['role'])){
                $role_err="Role panitia tidak boleh kosong";
            }else{
                $role=test_input($_POST['role']);
                $role=EscapeString($role);
            }
            $FileName=$_FILES['foto_panitia']['name'];
            $FileDir=$_FILES['foto_panitia']['tmp_name'];
            $FileSize=$_FILES['foto_panitia']['size'];
            $FileDestination='../img/';
            $FileExtension=strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
            $FileValid=array('jpeg','jpg','png');
            $FileItem=$username.".".$FileExtension;
            if(in_array($FileExtension, $FileValid)){
                if($FileSize > 150000){
                    $foto_panitia_err="Foto panitia tidak boleh lebih  dari 150 KB";
                }else{
                    $foto_panitia=$FileDir;
                }
            }else{
                $foto_panitia_err="Maaf format foto hanya boleh jpg, jpeg atau png";
            }
            if(empty($username_err) && empty($password_err) && empty($confir_password_err) && empty($email_err) && empty($nama_err) && empty($role_err) && empty($foto_panitia_err)){
                if(PanitiaTambah($username, $password, $email, $nama, $role, $foto_panitia)):
                    $simpan='
                           
                            <div class="container-fluid mt-4">                            
                                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                        <i class="zmdi zmdi-check-circle"></i>
                                        <span class="content">Panitia baru berhasil ditambahkan</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>';
                            
                           
                    
                else:
                    $simpan='<div class="container-fluid mt-4">
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="zmdi zmdi-close-circle"></i>
                                        <span class="content">Data gagal disimpan.</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>
                    ';

                endif;
                
            }
        }
    ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Tambah Panita</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php echo $simpan; ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <div class="card-body">                                      
                                           <div class="card-title">
                                                <h3 class="text-center title-2">Panitia</h3>
                                            </div>
                                            <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="username" class="control-label mb-1">Username</label>  
                                                    <input class="form-control" type="text" id="username" name="username" required="" placeholder="Masukan username untuk panitia">
                                                    <span class="text-danger"><?php echo $username_err; ?></span>               
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="password" class="control-label mb-1">Password</label>  
                                                            <input class="form-control" type="password" id="password" name="password" required="" placeholder="Masukan password">
                                                            <span class="text-danger"><?php echo $password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="confir_password" class="control-label mb-1">Konfirmasi Password</label>  
                                                            <input class="form-control" type="password" id="confir_password" name="confir_password" required="" placeholder="Konfirmasi password">
                                                            <span class="text-danger"><?php echo $confir_password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                </div>                                
                                                 <div class="form-group">
                                                    <label for="email" class="control-label mb-1">E-mail</label>  
                                                    <input class="form-control" type="text" id="email" name="email" required="" placeholder="Masukan email">
                                                    <span class="text-danger"><?php echo $email_err; ?></span>               
                                                </div> 
                                                 <div class="form-group">
                                                    <label for="nama" class="control-label mb-1">Nama Lengkap</label>  
                                                    <input class="form-control" type="text" id="nama" name="nama" required="" placeholder="Masukan nama lengkap panitia">
                                                    <span class="text-danger"><?php echo $nama_err; ?></span>               
                                                </div>                                                    
                                                <div class="form-group">
                                                    <label for="role" class="control-label mb-1"> role</label>
                                                        <select class="form-control" id="role" name="role">
                                                           <?php
                                                                $SelectRole=SelectRole();
                                                                while($role=$SelectRole->fetch_array()){
                                                                    echo '
                                                                    <option value='.$role['name_role'].'>'.$role['name_role'].'</option>
                                                                    ';
                                                                }
                                                                $SelectRole->free_result();
                                                            ?>                                                                                         
                                                        </select>
                                                        <span class="text-danger"><?php echo $role_err; ?></span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="foto_panitia" class="control-label mb-1">Foto</label>  
                                                    <input class="form-control" type="file" id="foto_panitia" name="foto_panitia" required="">
                                                    <span class="text-danger"><?php echo $foto_panitia_err; ?></span>               
                                                </div>                              
                                                <div class="form-group">
                                                    <button id="tambah_panitia" name="tambah_panitia" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fas fa-user-circle"></i>&nbsp;
                                                    <span id="tambah_panitia">Simpan</span>
                                                    <span id="tambah_panitia" style="display:none;">Sending…</span>
                                                    </button>
                                                </div>
                                            </form>

                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php }elseif($_GET['page']=='panitia-detail'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Panita</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php 
        if(!PanitiaDetail($_GET['id'])){
             echo'
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>

                ';
        }else{
            PanitiaDetail_load();
        }
    ?>
<?php }elseif($_GET['page']=='panitia-edit'){ ?>

    <?php
     if(!PanitiaDetail($_GET['id'])){
             echo'
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>

                ';
        }
         $username_err = $password_err = $confir_password_err = $nama_err = $email_err = $role_err = $foto_panitia_err = $simpan = "";
        if(isset($_POST['update_panitia'])){
            if(empty(trim($_POST['username']))){
                $username_err="Username Panitia tidak boleh kosong";
            }elseif(ValidateName($_POST['username'])){
                $username_err="Username hanya boleh karakter alphabet";
            }else{
               if(trim($_POST['username'])!=$username):
                    if(CekUsername($_POST['username'])){
                        $username_err="Maaf username tersebut sudah digunakan";
                    }else{
                        $username=test_input($_POST['username']);
                    }
                else:
                  $username=test_input($_POST['username']);
                  $username=EscapeString($username);
                endif;
            }
            if(empty(trim($_POST['password']))){
                $password_err="Password tidak boleh kosong";
            }elseif(strlen($_POST['password'])<6){
                $password_err="Password tidak boleh kurang dari 6 karakater";
            }else{
                $password=trim($_POST['password']);
            }
            if(empty(trim($_POST['confir_password']))){
                $confir_password_err="Konfirmasi passwird tidak boleh kosong";
            }else{
                $confir_password=trim($_POST['confir_password']);
                if(empty($password_err)&& ($password!=$confir_password)){
                    $confir_password_err="Konfirmasi password tidak cocok";
                }
            }
            if(empty(trim($_POST['email']))){
                $email_err="Email tidak boleh kosong";
             }elseif(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
                $email_err="Format penulisan email salah";
            }else{
                if(trim($_POST['email'])!=$email):
                    if(CekEmail($_POST['email'])){
                        $email_err="Maaf email tersebut sudah digunakan";
                    }else{
                        $email=test_input($_POST['email']);
                        $email=EscapeString($email);
                    }
                else:
                    $email=test_input($_POST['email']);
                    $email=EscapeString($email);
                endif;
            }
            if(empty($_POST['nama'])){
                $nama_err="Nama lengkap panitia tidak boleh kosong";
            }else{
                $nama=test_input($_POST['nama']);
                $nama=EscapeString($nama);
            }
            if(empty($_POST['role'])){
                $role_err="Role panitia tidak boleh kosong";
            }else{
                $role=test_input($_POST['role']);
                $role=EscapeString($role);
            }
            if(empty($_FILES['foto_panitia']['tmp_name'])):
                $FileItem=$foto_panitia;
            else:
                /*
                if(!empty($foto_panitia)){
                $foto_panitia_err="Untuk mengunggah foto baru silahkan hapus dulu foto sebelumnya";
                echo "<meta http-equiv=\"refresh\"content=\"5;\"/>";
                }
                */
                $FileName=$_FILES['foto_panitia']['name'];
                $FileDir=$_FILES['foto_panitia']['tmp_name'];
                $FileSize=$_FILES['foto_panitia']['size'];
                $FileDestination='../img/';
                $FileExtension=strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
                $FileValid=array('jpeg','jpg','png');
                $FileItem=$username.".".$FileExtension;
                if(in_array($FileExtension, $FileValid)){
                    if($FileSize > 150000){
                        $foto_panitia_err="Foto panitia tidak boleh lebih  dari 150 KB";
                    }else{
                        $foto_panitia=$FileDir;
                    }
                }else{
                    $foto_panitia_err="Maaf format foto hanya boleh jpg, jpeg atau png";
                }
            endif;

            if(empty($username_err) && empty($password_err) && empty($confir_password_err) && empty($email_err) && empty($nama_err) && empty($role_err) && empty($foto_panitia_err)){
                if(PanitiaUpdate($username, $password, $email, $nama, $role, $foto_panitia, $uid)):
                    $simpan='
                           
                            <div class="container-fluid mt-4">                            
                                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                        <i class="zmdi zmdi-check-circle"></i>
                                        <span class="content">Data berhasil diperbaharui</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>';
                            
                     echo "
                     <meta http-equiv=\"refresh\"content=\"5;URL=?page=panitia\" />
                     ";      
                    
                else:
                    $simpan='<div class="container-fluid mt-4">
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="zmdi zmdi-close-circle"></i>
                                        <span class="content">Data gagal disimpan.</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>
                    ';

                endif;
                
            }
        }
     ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Update Panita</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php echo $simpan; ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                  
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <div class="card-body">    
                                    <div class="float-right mt-3 mb-4">
                                     <img src="../img/<?php echo $foto_panitia; ?>" width="60" height="80" class="img-fluid" alt="foto">
                                    </div>                                                               
                                           <div class="card-title">
                                                <h3 class="text-center title-2">Update Panitia</h3>
                                            </div>

                                            <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="username" class="control-label mb-1">Username</label>  
                                                    <input class="form-control" type="text" id="username" name="username" value="<?php echo $username; ?>" required="" placeholder="Masukan username untuk panitia">
                                                    <span class="text-danger"><?php echo $username_err; ?></span>               
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="password" class="control-label mb-1">Password</label>  
                                                            <input class="form-control" type="password" id="password" name="password" required="" placeholder="Masukan password">
                                                            <span class="text-danger"><?php echo $password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="confir_password" class="control-label mb-1">Konfirmasi Password</label>  
                                                            <input class="form-control" type="password" id="confir_password" name="confir_password" required="" placeholder="Konfirmasi password">
                                                            <span class="text-danger"><?php echo $confir_password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                </div>                                
                                                 <div class="form-group">
                                                    <label for="email" class="control-label mb-1">E-mail</label>  
                                                    <input class="form-control" type="text" id="email" name="email" value="<?php echo $email; ?>" required="" placeholder="Masukan email">
                                                    <span class="text-danger"><?php echo $email_err; ?></span>               
                                                </div> 
                                                 <div class="form-group">
                                                    <label for="nama" class="control-label mb-1">Nama Lengkap</label>  
                                                    <input class="form-control" type="text" id="nama" name="nama" value="<?php echo $nama; ?>" required="" placeholder="Masukan nama lengkap panitia">
                                                    <span class="text-danger"><?php echo $nama_err; ?></span>               
                                                </div>                                                    
                                                <div class="form-group">
                                                    <label for="role" class="control-label mb-1"> role</label>
                                                        <select class="form-control" id="role" name="role">
                                                            <option value="<?php echo $role; ?>"><?php echo $role; ?></option>
                                                           <?php
                                                                $SelectRole=SelectRole();
                                                                while($role=$SelectRole->fetch_array()){
                                                                    echo '
                                                                    <option value='.$role['name_role'].'>'.$role['name_role'].'</option>
                                                                    ';
                                                                }
                                                                $SelectRole->free_result();
                                                            ?>                                                                                         
                                                        </select>
                                                        <span class="text-danger"><?php echo $role_err; ?></span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="foto_panitia" class="control-label mb-1">Foto</label>                  
           
                                                    <input class="form-control" type="file" id="foto_panitia" name="foto_panitia">
                                                    <span class="text-danger"><?php echo $foto_panitia_err; ?></span>
                                                                   
                                                </div>                              
                                                <div class="form-group">
                                                    <button id="update_panitia" name="update_panitia" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fas fa-user-circle"></i>&nbsp;
                                                    <span id="update_panitia">Simpan</span>
                                                    <span id="update_panitia" style="display:none;">Sending…</span>
                                                    </button>
                                                </div>
                                            </form>

                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php }elseif($_GET['page']=='panitia-delete'){ ?>
    <?php
     if(!PanitiaDetail($_GET['id'])){
             echo'
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>

                ';
        }else{
            PanitiaDelete_load();
        }   


    ?>
<?php }elseif($_GET['page']=='jalur-daftar'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Jalur Pendaftaran</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php LoadJalur_Daftar(); ?>
<?php }elseif($_GET['page']=='jalur-delete'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Delete jalur daftar</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php
    if(DeleteJalur(trim($_GET['id']))):
          $simpan='
                      
                        <div class="container-fluid mt-4">                            
                            <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                    <i class="zmdi zmdi-check-circle"></i>
                                    <span class="content">Data berhasil dihapus</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>';
                         echo " <meta http-equiv=\"refresh\"content=\"1;URL=?page=jalur-daftar\" />
                        ";
                       
                
            else:
                $simpan='<div class="container-fluid mt-4">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="zmdi zmdi-close-circle"></i>
                                    <span class="content">Data gagal dihapus.</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>
                ';
    endif;
    echo $simpan;
    ?>
<?php }elseif($_GET['page']=='jurusan'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Jurusan</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php Load_Jurusan(); ?>
<?php }elseif($_GET['page']=='jurusan-delete'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Delete jurusan</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php
    if(DeleteJurusan(trim($_GET['id']))):
          $simpan='
                      
                        <div class="container-fluid mt-4">                            
                            <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                    <i class="zmdi zmdi-check-circle"></i>
                                    <span class="content">Data berhasil dihapus</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>';
                         echo " <meta http-equiv=\"refresh\"content=\"3;URL=?page=jurusan\" />
                        ";
                       
                
            else:
                $simpan='<div class="container-fluid mt-4">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="zmdi zmdi-close-circle"></i>
                                    <span class="content">Data gagal dihapus.</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>
                ';
    endif;
    echo $simpan;
    ?>
<?php }elseif($_GET['page']=='kelas'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Kelas</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php Load_Kelas(); ?>
<?php }elseif($_GET['page']=='kelas-delete'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Delete kelas</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php
    if(DeleteKelas(trim($_GET['id']))):
          $simpan='
                      
                        <div class="container-fluid mt-4">                            
                            <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                    <i class="zmdi zmdi-check-circle"></i>
                                    <span class="content">Data berhasil dihapus</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>';
                         echo " <meta http-equiv=\"refresh\"content=\"3;URL=?page=kelas\" />
                        ";
                       
                
            else:
                $simpan='<div class="container-fluid mt-4">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="zmdi zmdi-close-circle"></i>
                                    <span class="content">Data gagal dihapus.</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>
                ';
    endif;
    echo $simpan;
    ?>    
<?php }elseif($_GET['page']=='setting'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Setting</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
        <?php LoadSetting();
         $d=(DB_NAME);
         $d.='.sql'; 
        ?>

        <?php
        $DataSetting=DataSetting();
        $Row=$DataSetting->fetch_array();       
        $logo_situs = $Row['logo_situs'];
        $sidebarlogo_situs = $Row['sidebarlogo_situs'];
        $pendaftaran = $Row['pendaftaran'];    
        $id = $Row['id'];

        $logo_situs_err = $sidebarlogo_situs_err = $simpan ="";
        if(isset($_POST['update_logo'])){
            if(empty($_FILES['logo_situs']['tmp_name'])):
                $FileItem=$logo_situs;
            else:
                
                $FileName=$_FILES['logo_situs']['name'];
                $FileDir=$_FILES['logo_situs']['tmp_name'];
                $FileSize=$_FILES['logo_situs']['size'];
                $FileDestination='../../assets/img/';
                $FileExtension=strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
                $FileValid=array('jpg','jpeg','png');
                $FileItem="logo.".$FileExtension;
                if(in_array($FileExtension, $FileValid)){
                    if($FileSize>300000){
                      $logo_situs_err="Ukuran logo tidak boleh lebih dari 300KB";
                    }else{
                      $logo_situs=$FileDir;
                    }
                  }else{
                    $logo_situs_err="Wajib diisi dengan format JPG, JPEG, atau PNG";
                  }
            endif;
            
            if(empty($logo_situs_err)){

                if(SimpanLogo($logo_situs, $id)):
                      $simpan='
                           
                            <div class="container-fluid mt-4">                            
                                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                        <i class="zmdi zmdi-check-circle"></i>
                                        <span class="content">Data logo berhasil disimpan</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>';
                            
                    echo "
                     <meta http-equiv=\"refresh\"content=\"2;URL=?page=setting\" />
                     ";     
                    
                else:
                    $simpan='<div class="container-fluid mt-4">
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="zmdi zmdi-close-circle"></i>
                                        <span class="content">Data gagal disimpan.</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>
                    ';

                endif;
            }    
        }
        if(isset($_POST['update_sidebarlogo'])){
            if(empty($_FILES['sidebarlogo_situs']['tmp_name'])):
                $FileItem=$sidebarlogo_situs;
            else:
                
                $FileName=$_FILES['sidebarlogo_situs']['name'];
                $FileDir=$_FILES['sidebarlogo_situs']['tmp_name'];
                $FileSize=$_FILES['sidebarlogo_situs']['size'];
                $FileDestination='../../assets/img/';
                $FileExtension=strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
                $FileValid=array('jpg','jpeg','png');
                $FileItem="sidebar".".".$FileExtension;
                if(in_array($FileExtension, $FileValid)){
                    if($FileSize>300000){
                      $sidebarlogo_situs_err="Ukuran logo tidak boleh lebih dari 300KB";
                    }else{
                      $sidebarlogo_situs=$FileDir;
                    }
                  }else{
                    $sidebarlogo_situs_err="Wajib diisi dengan format JPG, JPEG, atau PNG";
                  }
            endif;
             if(empty($sidebarlogo_situs_err)){

                if(SimpanLogoSidebar($sidebarlogo_situs, $id)):
                      $simpan='
                           
                            <div class="container-fluid mt-4">                            
                                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                        <i class="zmdi zmdi-check-circle"></i>
                                        <span class="content">Data Logo Sidebar berhasil disimpan</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>';
                            
                    echo "
                     <meta http-equiv=\"refresh\"content=\"2;URL=?page=setting\" />
                     ";      
                    
                else:
                    $simpan='<div class="container-fluid mt-4">
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="zmdi zmdi-close-circle"></i>
                                        <span class="content">Data gagal dihapus.</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>
                    ';

                endif;
            }    
        }
        
        echo $simpan;
        echo'
        <form action="'.htmlspecialchars(basename($_SERVER['REQUEST_URI'])).'" method="post" enctype="multipart/form-data" novalidate="novalidate">
                <div class="form-group">
                    <label for="logo_situs" class="control-label mb-1">Logo</label>                                              
                            <input class="form-control" type="file" id="logo_situs" name="logo_situs">
                            <p>
                                <img class="img-fluid" src="../../assets/img/'.$logo_situs.'" width="30" height="30" alt="Belum ada" title="Logo Situs">
                            </p>
                            <em class="small">Logo/Icon situs disarankan ukuran 32 x 32 px Format PNG</em>               
                            <span class="text-danger">'.$logo_situs_err.'</span>
                </div>
                                            
                                                                                                                    
                <div class="form-group">
                        <button id="update_logo" name="update_logo" type="submit" class="btn btn-sm btn-info">
                                <i class="zmdi zmdi-settings fa-lg"></i>&nbsp;
                                <span id="update_logo">Simpan</span>
                                <span id="update_logo" style="display:none;">Sending…</span>
                                </button>
                </div>
        </form>
        <form action="'.htmlspecialchars(basename($_SERVER['REQUEST_URI'])).'" method="post" enctype="multipart/form-data" novalidate="novalidate">
                <div class="form-group">
                    <label for="sidebarlogo_situs" class="control-label mb-1">Logo Sidebar</label>                                              
                    <input id="sidebarlogo_situs" name="sidebarlogo_situs" type="file" class="form-control">
                        <p>
                        <img class="img-fluid" src="../../assets/img/'.$sidebarlogo_situs.'" width="30" height="30" alt="Belum ada" title="Logo Situs">
                        </p>
                        <em class="small">Logo disarankan ukuran 100x100 px Format PNG</em>                                                
                        <span class="text-danger">'.$sidebarlogo_situs_err.'</span>
                </div>                                            
                <div class="form-group">
                    <button id="update_sidebarlogo" name="update_sidebarlogo" type="submit" class="btn btn-sm btn-info">
                    <i class="zmdi zmdi-settings fa-lg"></i>&nbsp;
                    <span id="update_sidebarlogo">Simpan</span>
                    <span id="update_sidebarlogo" style="display:none;">Sending…</span>
                    </button>
                </div>
        </form>
        
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        ';
        ?>
<?php }elseif($_GET['page']=='reset'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Setting / Reset</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
    </section>
    
    
       
<?php }elseif($_GET['page']=='jadwal-test'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Jadwal Test</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
        <?php Load_JadwalTest(); ?>
<?php }elseif($_GET['page']=='account'){ ?>
    <?php  
      $username_err = $password_err = $confir_password_err = $nama_err = $email_err = $role_err = $foto_panitia_err = $simpan = "";
        if(isset($_POST['update_admin'])){
            if(empty(trim($_POST['username']))){
                $username_err="Username Panitia tidak boleh kosong";
            }elseif(ValidateName($_POST['username'])){
                $username_err="Username hanya boleh karakter alphabet";
            }else{
               if(trim($_POST['username'])!=$admin_username):
                    if(CekUsername($_POST['username'])){
                        $username_err="Maaf username tersebut sudah digunakan";
                    }else{
                        $username=test_input($_POST['username']);
                    }
                else:
                  $username=test_input($_POST['username']);
                  $username=EscapeString($username);
                endif;
            }
            if(empty(trim($_POST['password']))){
                $password_err="Password tidak boleh kosong";
            }elseif(strlen($_POST['password'])<6){
                $password_err="Password tidak boleh kurang dari 6 karakater";
            }else{
                $password=trim($_POST['password']);
            }
            if(empty(trim($_POST['confir_password']))){
                $confir_password_err="Konfirmasi passwird tidak boleh kosong";
            }else{
                $confir_password=trim($_POST['confir_password']);
                if(empty($password_err)&& ($password!=$confir_password)){
                    $confir_password_err="Konfirmasi password tidak cocok";
                }
            }
            if(empty(trim($_POST['email']))){
                $email_err="Email tidak boleh kosong";
            }elseif(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
                $email_err="Format penulisan email salah";
            }else{
                if(trim($_POST['email'])!=$admin_email):
                    if(CekEmail($_POST['email'])){
                        $email_err="Maaf email tersebut sudah digunakan";
                    }else{
                        $email=test_input($_POST['email']);
                        $email=EscapeString($email);
                    }
                else:
                    $email=test_input($_POST['email']);
                    $email=EscapeString($email);
                endif;
            }
            if(empty(trim($_POST['nama']))){
                $nama_err="Nama lengkap panitia tidak boleh kosong";
            }else{
                $nama=test_input($_POST['nama']);
                $nama=EscapeString($nama);
            }
           
            if(empty($_FILES['foto_panitia']['tmp_name'])):
               
                $foto_panitia=$Admin_row['foto_panitia'];
                $FileItem=$foto_panitia;
               
            else:
                /*
                if(!empty($foto_panitia)){
                $foto_panitia_err="Untuk mengunggah foto baru silahkan hapus dulu foto sebelumnya";
                echo "<meta http-equiv=\"refresh\"content=\"5;\"/>";
                }
                */
                $FileName=$_FILES['foto_panitia']['name'];
                $FileDir=$_FILES['foto_panitia']['tmp_name'];
                $FileSize=$_FILES['foto_panitia']['size'];
                $FileDestination='../img/';
                $FileExtension=strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
                $FileValid=array('jpeg','jpg','png');
                $FileItem=$username.".".$FileExtension;
                if(in_array($FileExtension, $FileValid)){
                    if($FileSize > 150000){
                        $foto_panitia_err="Foto panitia tidak boleh lebih  dari 150 KB";
                    }else{
                        $foto_panitia=$FileDir;
                    }
                }else{
                    $foto_panitia_err="Maaf format foto hanya boleh jpg, jpeg atau png";
                }
            endif;

            if(empty($username_err) && empty($password_err) && empty($confir_password_err) && empty($email_err) && empty($nama_err) && empty($foto_panitia_err)){
                if(UpdateAdmin($username, $password, $email, $nama, $foto_panitia, $admin_uid)):
            
                    $_SESSION['username']=$username;
                    $_SESSION['email']=$email;
                    $_SESSION['nama']=$nama;        
                    $_SESSION['foto']=$foto_panitia;

                   
                    $simpan='
                           
                            <div class="container-fluid mt-4">                            
                                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                        <i class="zmdi zmdi-check-circle"></i>
                                        <span class="content">Data Admin berhasil diperbaharui</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>';
                            
                     echo "
                     <meta http-equiv=\"refresh\"content=\"2;URL=?page=account\" />
                     ";      
                    
                else:
                    $simpan='<div class="container-fluid mt-4">
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="zmdi zmdi-close-circle"></i>
                                        <span class="content">Data gagal disimpan.</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>
                    ';

                endif;
                
            }
        }

    ?>

   <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Account</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
     <?php echo $simpan; ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                  
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <div class="card-body">    
                                    <div class="float-right mt-3 mb-4">
                                     <img src="../img/<?php echo $Admin_row['foto_panitia']; ?>" width="60" height="80" class="img-fluid" alt="foto">
                                    </div>                                                               
                                           <div class="card-title">
                                                <h3 class="text-center title-2">Account Admin</h3>
                                            </div>

                                            <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="username" class="control-label mb-1">Username</label>  
                                                    <input class="form-control" type="text" id="username" name="username" value="<?php echo $admin_username; ?>" required="" placeholder="Masukan username untuk panitia">
                                                    <span class="text-danger"><?php echo $username_err; ?></span>               
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="password" class="control-label mb-1">Password</label>  
                                                            <input class="form-control" type="password" id="password" name="password" required="" placeholder="Masukan password">
                                                            <span class="text-danger"><?php echo $password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="confir_password" class="control-label mb-1">Konfirmasi Password</label>  
                                                            <input class="form-control" type="password" id="confir_password" name="confir_password" required="" placeholder="Konfirmasi password">
                                                            <span class="text-danger"><?php echo $confir_password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                </div>                                
                                                 <div class="form-group">
                                                    <label for="email" class="control-label mb-1">E-mail</label>  
                                                    <input class="form-control" type="text" id="email" name="email" value="<?php echo $admin_email; ?>" required="" placeholder="Masukan email">
                                                    <span class="text-danger"><?php echo $email_err; ?></span>               
                                                </div> 
                                                 <div class="form-group">
                                                    <label for="nama" class="control-label mb-1">Nama Lengkap</label>  
                                                    <input class="form-control" type="text" id="nama" name="nama" value="<?php echo $admin_nama; ?>" required="" placeholder="Masukan nama lengkap panitia">
                                                    <span class="text-danger"><?php echo $nama_err; ?></span>               
                                                </div>                                                    
                                                
                                                <div class="form-group">
                                                    <label for="foto_panitia" class="control-label mb-1">Foto</label>                 
                                                    <input class="form-control" type="file" id="foto_panitia" name="foto_panitia">
                                                    <span class="text-danger"><?php echo $foto_panitia_err; ?></span>
                                                                   
                                                </div>                              
                                                <div class="form-group">
                                                    <button id="update_admin" name="update_admin" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fas fa-user-circle"></i>&nbsp;
                                                    <span id="update_admin">Simpan</span>
                                                    <span id="update_admin" style="display:none;">Sending…</span>
                                                    </button>
                                                </div>
                                            </form>

                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
<?php }elseif($_GET['page']=='reset-pass'){ ?>
    <section class="au-breadcrumb m-t-75">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                            <div class="col-md-12">
                                <div class="au-breadcrumb-content">
        <div class="au-breadcrumb-left">
                    <span class="au-breadcrumb-span">You are here:</span>
                <ul class="list-unstyled list-inline au-breadcrumb__list">
            <li class="list-inline-item active">
                <a href="?page=dashboard">Home</a>
            </li>
            <li class="list-inline-item seprate">
            <span>/</span>
            </li>
            <li class="list-inline-item">Reset Password</li>
            </ul>
        </div>
                                           
        </div>
        </div>
        </div>
         </div>
        </div>
    </section> 
         <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
         }else{
            Load_ResetPass();
         } 

         ?>  
<?php }elseif($_GET['page']=='logout'){ ?>
     <div class="main-content">
        <div class="section__content section__content--p30">
         <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                                   
                                    <div class="card-body">                                      
                                      <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
                                                
                                        Anda berhasil logout.
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                        </div>                                           
                                       
                                    </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        <?php UnsetDataUser(); ?>
<?php }elseif($_GET['page']=='pengaturan pembayaran'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Pengaturan Pembayaran</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
     <?php LoadUpdatePengaturanPembayaran(); ?>
<?php }else{ ?>
	<?php echo "
	<meta http-equiv=\"refresh\"content=\"0;URL=index.php?page=dashboard\" />
	";
	?>
<?php } ?>

<?php
footer();
?>
<script>
var ctx = document.getElementById("percent-chart93");
    if (ctx) {
      ctx.height = 280;
      var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          datasets: [
            {
              label: "My First dataset",
              data: [<?php echo $DashboardData['jml_pria']; ?>,<?php echo $DashboardData['jml_wanita']; ?>],
              backgroundColor: [
                '#00b5e9',
                '#fa4251'
              ],
              hoverBackgroundColor: [
                '#00b5e9',
                '#fa4251'
              ],
              borderWidth: [
                0, 0
              ],
              hoverBorderColor: [
                'transparent',
                'transparent'
              ]
            }
          ],
          labels: [
            'Pria',
            'Wanita'
          ]
        },
        options: {
          maintainAspectRatio: false,
          responsive: true,
          cutoutPercentage: 55,
          animation: {
            animateScale: true,
            animateRotate: true
          },
          legend: {
            display: false
          },
          tooltips: {
            titleFontFamily: "Poppins",
            xPadding: 15,
            yPadding: 10,
            caretPadding: 0,
            bodyFontSize: 16
          }
        }
      });
    }
</script>