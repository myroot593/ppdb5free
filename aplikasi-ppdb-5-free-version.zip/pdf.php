<?php
session_start();
require_once 'function/function.session.php';
require_once 'config/database.php';
require_once 'function/function.user.php';
require_once 'plugins/mpdf/mpdf.php';
  if(SessionUserCek()){
    header("location:login");
    }else{
    SessionActive();
    $id=$DSessionArray[0];
    $nama_akun=$DSessionArray[1];
    $email=$DSessionArray[2];
    $username=$DSessionArray[3];  
  }
  $dokumen='FORMULIR PENDAFTARAN'; 
  $mpdf=new mPDF('utf-8', 'A4'); 
  ob_start(); 
      $DataMhs=DataSiswa($id);
      $row=$DataMhs->fetch_array();    
      $id=$row['id'];
      $nomor_pendaftaran=$row['nomor_pendaftaran']; 
      $no_ktp=$row['no_ktp'];
      $nama=$row['nama']; 
      $nisn=$row['nisn'];
      $jenis_kelamin=$row['jl'];
      $tempat_lahir=$row['tempat_lahir'];
      $tanggal_lahir=$row['tanggal_lahir'];      
      $dusun=$row['dusun'];
      $rt=$row['rt'];
      $rw=$row['rw'];
      $desa=$row['desa'];
      $kecamatan=$row['kecamatan'];
      $kabupaten=$row['kabupaten'];
      $provinsi=$row['provinsi'];
      $foto=$row['foto'];
      $jurusan=$row['jurusan'];
      $kode_daftar=$row['kode_daftar'];       
      $tgl_daftar=$row['tgl_pendaftaran'];
      $nama_sekolah=$row['nama_sekolah'];
      $status=$row['status_pendaftaran'];
      $DataMhs->free_result();
      if(empty($nomor_pendaftaran)):
        echo "<meta http-equiv=\"refresh\"content=\"3;URL=home\"/>";
        die('Silahkan isi dan lengkap data pribadi terlebih dahulu');
        exit(0);
      endif;
      
      GlobalDataSitus();
      
          
echo '

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<style>
  body {font-family: sans-serif;
    font-size: 9pt;
    background: transparent url(\'bgbarcode.png\') repeat-y scroll left top;
  }

  h5, p { margin: 0pt;
  }
  table.items {
    font-size: 9pt; 
    border-collapse: collapse;
    
  }
  td { vertical-align: top; 
  }
  table thead td { background-color: #EEEEEE;
    text-align: center;
  }
  table tfoot td { background-color: #AAFFEE;
    text-align: center;
  }
  .barcode {
    padding: 1.5mm;
    margin: 0;
    vertical-align: top;
    color: #000000;
  }
  .barcodecell {
    text-align: center;
    vertical-align: middle;
    padding: 0;
  }
  .kapital{
    text-transform:uppercase;
  }
  
</style>
</head>
<body>

<table class="items" width="100%" cellpadding="2">
  <tbody>
      <tr>
        <td align="right" style="border-bottom:3px solid #403d3d;">
          <img src="assets/img/'.$GlobalDataSitus[7].'" width="90" height="90"/>
            
        </td>
        <td align="center" colspan="2" style="border-bottom:3px solid #403d3d;">
         <h2>'.$GlobalDataSitus[0].'</h2>
         <p>'.$GlobalDataSitus[1].'</p>
    
        </td>
      </tr>
  </tbody>
</table>
<br>
<table class="items" width="100%" cellpadding="6">
  <tbody>
    </tr>
      <tr>
        <td colspan="3"><h3>FORMULIR PENDAFTARAN</h3></td>
        <td rowspan="8" valign="top">
          <div align="center">
             <img src="content/foto/'.$foto.'" width="90" height="120"/><br>
            
          </div>
        </td>      
      </tr>
      <tr>
        <td colspan="4"><b>DATA POKOK</b></td>
      </tr>
      <tr>
        <td>No. Registrasi </td>
        <td>:</td>
        <td>'.$nomor_pendaftaran.'/PPDB/'.date('Y').'</td>
        <td>&nbsp;</td>      
      </tr>
      <tr>
        <td>No. KTP/NIK </td>
        <td>:</td>
        <td>'.$no_ktp.'</td> 
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Nama</td>
        <td>:</td>
        <td class="kapital">'.$nama.'</td> 
        <td>&nbsp;</td>    
      </tr>
      <tr>
        <td>Tgl. Lahir </td>
        <td>:</td>
        <td class="kapital">'.$tempat_lahir.', '.$tanggal_lahir.'</td> 
        <td>&nbsp;</td>      
      </tr>
      <tr>
        <td>Jenis Kelamin </td>
        <td>:</td>
        <td class="kapital">'.$jenis_kelamin.'</td>  
        <td>&nbsp;</td>     
      </tr>
      <tr>
        <td>Alamat</td>
        <td>:</td>
        <td class="kapital">Dusun. '.$dusun.' RT/RW '.$rt.'/'.$rw.' Desa. '.$desa.' Kec. '.$kecamatan.' Kabupaten. '.$kabupaten.' provinsi '.$provinsi.'</td>  
        <td>&nbsp;</td>   
      </tr>
      <tr>
        <td>Asal Sekolah</td>
        <td>:</td>
        <td class="kapital">'.$nama_sekolah.'</td>  
        <td>&nbsp;</td>   
      </tr>
      <tr>
        <td>Tgl. Pendaftaran</td>
        <td>:</td>
        <td>'.$tgl_daftar.'</td> 
        <td>&nbsp;</td>    
      </tr>
      ';
      if(!empty($jurusan)):
        echo'
        <tr>
          <td>Jurusan</td>
          <td>:</td>
          <td>'.$jurusan.'</td>
          <td>&nbsp;</td>     
        </tr>';
      endif;
      echo'
     <tr>
        <td>Status Pendaftaran</td>
        <td>:</td>
        <td>'.$status.'</td> 
        <td>&nbsp;</td>    
      </tr>
  </tbody>
</table>
<br>
 
<table style="border-top:3px dashed #ccc; width: 700px; margin-bottom: 15px;">
    <tr>
      <td colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td>Hasil Verifikasi [ ] Lulus [ ] Tidak</td>
      <td>&nbsp;</td>
      <td>Tanggal verifikasi : </td>
      <td>&nbsp;</td>
      <td>Tanggal Verifikasi Online: </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Petugas Verifikator Berkas </td>
      <td>&nbsp;</td>
      <td>Petugas Verifikator Online</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Nama</td>
      <td>&nbsp;</td>
      <td>Nama</td>
    </tr>
</table>
    <p align="center"><br>"Demikian data pribadi ini saya buat dengan sebenarnya dan bila ternyata isian yang dibuat tidak benar, saya bersedia menanggung akibat hukum yang ditimbulkannya"<br></p>  
    <p style="font-size:9px;">
    Catatan :<br>
    UU ITE No 11 Tahun 2008 Pasal 5 Ayat 1 : &quot;Informasi Elektronik dan/atau hasil cetaknya merupakan alat bukti yang sah&quot;
   </p>
</body>
</html>
';

$html = ob_get_contents(); 
ob_end_clean();
$mpdf->WriteHTML($stylesheet,1);
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($dokumen.".pdf" ,'I');
exit;
?>
