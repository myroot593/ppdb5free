<?php
session_start();
require_once 'function/function.session.php';
SessionActive();
DeleteSession($DSessionArray);
?>