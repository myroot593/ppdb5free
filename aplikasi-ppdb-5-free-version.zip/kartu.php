<?php
session_start();
require_once 'function/function.session.php';
require_once 'config/database.php';
require_once 'function/function.user.php';
require_once 'plugins/mpdf/mpdf.php';
  if(SessionUserCek()){
    header("location:login");
    }else{
    SessionActive();
    $id=$DSessionArray[0];
    $nama_akun=$DSessionArray[1];
    $email=$DSessionArray[2];
    $username=$DSessionArray[3];  
  }
  $dokumen='FORMULIR PENDAFTARAN'; 
  $mpdf=new mPDF('utf-8', 'A4'); 
  ob_start(); 
      $DataMhs=DataSiswa($id);
      $row=$DataMhs->fetch_array();    
      $id=$row['id'];
      $nomor_pendaftaran=$row['nomor_pendaftaran'];
      $nama=$row['nama'];
      $asal_sekolah=$row['asal_sekolah']; 
      $nama_sekolah=$row['nama_sekolah'];
      $foto=$row['foto'];
      $jalur_pendaftaran=$row['jalur_pendaftaran'];
      $status_pendaftaran=$row['status_pendaftaran'];

      $DataMhs->free_result();

      $jadwal=Tampil_JadwalTest();
      $jadwal_test=$jadwal->fetch_array();
      $tanggal_test=$jadwal_test['tanggal_test'];
      $waktu_test=$jadwal_test['waktu_test'];
      $materi=$jadwal_test['materi'];
      $jadwal->free_result();

      
      $tahun_sekarang=date('Y');
      $tahun_selanjutnya=$tahun_sekarang+1;
      if($status_pendaftaran!='Terverifikasi'){
        echo "<meta http-equiv=\"refresh\"content=\"3;URL=home\"/>";
        die("Error : Anda belum terverifikasi, belum bisa cetak kartu peserta");
        exit(0);
      }
      if(empty($nomor_pendaftaran)):
        echo "<meta http-equiv=\"refresh\"content=\"3;URL=home\"/>";
        die('Silahkan isi dan lengkap data pribadi terlebih dahulu');
        exit(0);
      endif;
      if(empty($tanggal_lahir)):
           //explode tgl lahir
        $tgl=NULL; 
      else:
        $tgl=explode("-", $tanggal_lahir); 
      endif; 
      GlobalDataSitus();
          
echo '

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<style>
  body {font-family: sans-serif;
    font-size: 9pt;
    background: transparent url(\'bgbarcode.png\') repeat-y scroll left top;
  }

  h5, p { margin: 0pt;
  }
  table.items {
    font-size: 9pt; 
    border-collapse: collapse;
    
  }
  td { vertical-align: top; 
  }
  table thead td { background-color: #EEEEEE;
    text-align: center;
  }
  table tfoot td { background-color: #AAFFEE;
    text-align: center;
  }
  .barcode {
    padding: 1.5mm;
    margin: 0;
    vertical-align: top;
    color: #000000;
  }
  .barcodecell {
    text-align: center;
    vertical-align: middle;
    padding: 0;
  }
  .border-uni{
    border-bottom:1px solid #403d3d;
    border-left:1px solid #403d3d;
    
  }
  .border-center{
    border-bottom:1px solid #403d3d;

  }
  .border-center-right{
    border-bottom:1px solid #403d3d;
    border-right:1px solid #403d3d;
  }

  .kapital{text-transform:uppercase;}
  

  
</style>
</head>
<body>

<table class="items" width="340px" cellpadding="4">
  <tr style="border:1px solid #403d3d;" align="center">
    <td style="border-right:1px solid #403d3d;" align="center">
       <img src="assets/img/'.$GlobalDataSitus[7].'" width="50" height="50"/>            
    </td>
    <td colspan="1" align="center" style="border-bottom:1px solid #403d3d;"><p align="center"><strong>KARTU PESERTA</strong><br />
        <strong>'.$GlobalDataSitus[0].'</strong><strong><br>Tahun Pelajaran '.$tahun_sekarang.'/ '.$tahun_selanjutnya.'</strong></p>    </td>
  </tr>
  <tr>
    <td class="border-uni">No. Peserta </td>

    <td class="border-center-right">:'.$nomor_pendaftaran.'</td>
  </tr>
  <tr>
    <td class="border-uni">Nama</td>

    <td class="border-center-right kapital">: '.$nama.'</td>
  </tr>
  <tr>
    <td class="border-uni">Asal Sekolah </td>
  
    <td class="border-center-right kapital">: '.$nama_sekolah.'</td>
  </tr>
  <tr>
    <td class="border-uni">Pelaksanaan Test </td>

    <td class="border-center-right kapital">: '.$tanggal_test.'</td>
  </tr>
  <tr>
    <td class="border-uni">Pukul</td>
    <td class="border-center-right">: '.$waktu_test.'</td>
  </tr>
  <tr>
    <td align="center" class="border-uni">
          <img src="content/foto/'.$foto.'" width="60" height="80"/>            
    </td>
    <td class="border-center-right kapital" colspan="1">'.$materi.'</td>
  </tr>
</table>

</body>
</html>
';

$html = ob_get_contents(); 
ob_end_clean();
$mpdf->WriteHTML($stylesheet,1);
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($dokumen.".pdf" ,'I');
exit;
?>
