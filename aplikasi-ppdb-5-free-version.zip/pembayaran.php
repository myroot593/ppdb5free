<?php
session_start();
if(!isset($_SESSION['username'])){
	header("location:buat-akun");
}
?>
<?php
require_once 'function/function.session.php';
require_once 'config/database.php';
require_once 'function/function.user.php';
if(SessionUserCek()){
		header("location:login");
		}else{
		SessionActive();
	
		$id=$DSessionArray[0];
		$nama_akun=$DSessionArray[1];
		$email=$DSessionArray[2];
		$username=$DSessionArray[3];		
		
	}
?>
<?php 
	head();
	css();
	navigasi();
	if(!isset($_GET['page'])){$_GET['page']='';}
?>

<?php

	$DataMhs=DataSiswa($id);
	$row=$DataMhs->fetch_array();	
	$no_ktp=$row['no_ktp'];
	$nama=$row['nama'];	
	$nisn=$row['nisn'];			
	$kode_refrensi=$row['kode_refrensi'];
	$bukti_transfer=$row['bukti_transfer'];
	$status_pembayaran=$row['status_pembayaran'];	
	$nomor_awal=date('Y').date('m');
	$nomor_pendaftaran=$nomor_awal.$id;
	
	$setting_pembayaran=PengaturanPembayaran();
    $pe_bayar=$setting_pembayaran->fetch_array();
    $setting_pembayaran->free_result();




?>
<?php 
//validasi pembayaran
	$simpan= $bukti_transfer_err="";
	if(isset($_POST['simpan_pembayaran'])){
		if(empty($_FILES['bukti_transfer']['tmp_name'])):
			$FileItem=$bukti_transfer;
		else:
			if(!empty($bukti_transfer)){
				$bukti_transfer_err="Hapus foto bukti pembayaran sebelumnya terlebih dahulu !";
				echo "<meta http-equiv=\"refresh\"content=\"3;\" />";
			}
			$FileName=$_FILES['bukti_transfer']['name'];
			$FileDir=$_FILES['bukti_transfer']['tmp_name'];
			$FileSize=$_FILES['bukti_transfer']['size'];
			$FileDestination='content/pembayaran/';
			$FileExtension=strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
			$FileValid=array('jpg','jpeg','png');
      		$FileItem=$nama.$kode_refrensi.".".$FileExtension;
      		if(in_array($FileExtension, $FileValid)){
			    if($FileSize>300000){
			      $bukti_transfer_err="Ukuran file tidak boleh lebih dari 300KB";
			    }else{
			      $bukti_transfer=$FileDir;
			    }

			  }else{
			    $bukti_transfer_err="Wajib diisi dengan format JPG, JPEG, atau PNG";
			  }
		endif;
		if(empty($bukti_transfer_err)){
			if(SimpanDataPembayaran($nomor_pendaftaran, $nama, $bukti_transfer, $id)):
				
				$simpan="<div class='alert alert-success mt-4'>Data pembayaran berhasil disimpan</div>";
				echo "
				<meta http-equiv=\"refresh\"content=\"3;URL=home\"/>
				";
			else:
				$simpan="<div class='alert alert-danger'>Data pembayaran gagal disimpan</div>";
			endif;
		}
		
	}
?>
<?php
//remove pembayaran
	if(isset($_POST['remove_bayar'])){
		$DataUpdate=NULL;
		if(RemoveBayar($bukti_transfer) && RemoveBayarUpdate($DataUpdate, $id)):
			$simpan="<div class='mt-4 alert alert-success'>Data bukti pembayaran berhasil dihapus</div>";
						echo "<meta http-equiv=\"refresh\"content=\"3;URL=home\"/>";
		else:
			$simpan="<div class='mt-4 alert alert-danger'>Data gagal dihapus</div>";
						
		endif;
		
	}
?>
<div id="content" class="p-4 p-md-5 pt-5">
	<?php echo $simpan; ?> 
		
    	<ol class="breadcrumb mt-4">
	                <li class="breadcrumb-item">
	                  <a href="home">Kembali</a>
	                </li>
	                <li class="breadcrumb-item active">Konfirmasi Pembayaran</li>
	    </ol>
	    <?php 
	    	if($status_pembayaran=='Lunas'):
	    		echo '

	    			<div class="alert alert-dismissible alert-info">
					    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					  Status pembayaran Anda sudah Terverifikasi, silahkan simpan kwitansi bukti pembayaran Anda disni <a href="kwitansi.php" target="_blank"> SIMPAN KWITANSI</a>
					</div>
	    		';
	    	else:
	    		if($pe_bayar['status_pembayaran']=='Aktif'):
		    		echo
			    		' 
			    		<div class="alert alert-dismissible alert-info">
					    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						 	Silahkan untuk memenuhi biaya pendaftaran terlebih dahulu untuk melanjutkan proses pendaftaran. Pembayaran Anda akan diverifikasi oleh bendahara atau bisa menghubungi langsung pihak panitia Bag. Bendahara supaya mempercepat proses verifikasi
						</div>
						';
				elseif($pe_bayar['status_pembayaran']=='Tidak Aktif'):
					echo '

						<div class="alert alert-dismissible alert-info">
					    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						 		Anda tetap bisa mengisi seluruh data meskipun Anda belum mengisi pembayaran 
						</div>

					';
				else:
					echo '

						<div class="alert alert-dismissible alert-info">
					    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						 		Tidak ada biaya pendaftaran. Anda tidak perlu melakukan pembayaran
						</div>

					';
				endif;
	    	endif;	

	    ?>
	   
	    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post" enctype="multipart/form-data">
	       <div class="form-group">
		       	<label>Nama : </label>
		       	<fieldset disabled>
		       	<input class="form-control" value="<?php echo $nama; ?>">
		        </fieldset>
		       	
	       </div>
	       <div class="form-group">
	       		<label>Kode Refrensi :</label>
	       		<fieldset disabled>
	       			<input class="form-control" value="<?php echo $kode_refrensi; ?>">
	       		</fieldset>
	       		<em class="small">Kode refrensi ini masukan saat melakukan pembayaran</em>
	       </div>
	        <div class="form-group">
	       		<label>Jumlah Pembayaran :</label>
	       		<fieldset disabled>
	       			<input class="form-control" value="Rp. <?php echo $pe_bayar['jumlah_pembayaran']; ?>.<?php echo $kode_refrensi; ?>">
	       		</fieldset>
	       		<em class="small">Jumlah pembayaran utama adalah <?php echo $pe_bayar['jumlah_pembayaran']; ?>.000 ditambah 3 digit kode refrensi. Untuk mempermudah proses verifikasi pembayaran</em>
	       </div>
	       <div class="form-group">
		       	<label>Bukti Transfer</label>
		       	<input class="form-control" type="file" name="bukti_transfer" id="bukti_transfer">
		       	<em class="small"> Bukti Tf Max. 300 KB</em>
					<p><img class="img-fluid" width="80" height="100" alt="foto" title="foto" src="content/pembayaran/<?php echo $bukti_transfer; ?>"></p>

				<?php if(!empty($bukti_transfer)): echo '<button class="btn btn-danger btn-sm" type="submit" name="remove_bayar" id="remove_bayar">Hapus</button>'; endif; ?>

		       	<span class="text-danger"><?php echo $bukti_transfer_err; ?></span>
	       </div>
	       <button type="submit"name="simpan_pembayaran" id="simpan_pembayaran" class= "btn btn-primary btn-md">Simpan</button>
	    </form>

	    <?php if(!empty($pe_bayar['rek_pembayaran'])) echo '<div class="mt-4 alert alert-dismissible alert-info">
	    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	    	'.htmlspecialchars_decode($pe_bayar['rek_pembayaran']).'

	    	</div>'; ?>
	<!--Container Fluid End -->	
</div>

<?php
footer();
?>
	
