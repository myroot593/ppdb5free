<?php
session_start();
if(isset($_SESSION['username'])){
   header("location: home");
  exit;
}

?>
<?php
require_once 'config/database.php';
require_once 'function/function.user.php';
?>
<?php 
	GlobalDataSitus();
	if($GlobalDataSitus[8]=='Tutup'){
		header("location:home?page=tutup");
	}elseif($GlobalDataSitus[8]=='Perawatan'){
		header("location:home?page=perawatan");
	}else{
		if($GlobalDataSitus[8]=='Belum Dibuka'){
		header("location:home?page=belum-dibuka");
		}
	}

	head();
	css();
	navigasi();
	$tgl_pendaftaran=TampilTanggal();
	$kode_daftar=rand(100,1000);
	$virtual_account=$GlobalDataSitus[9].mt_rand(10000000,99999999);
?>
<?php

$nama = $email = $username = $password = $konfir_password = $simpan = "";
$nama_err = $email_err = $username_err = $password_err = $konfir_password_err = $virtual_account_err = "";
if(isset($_POST['daftar'])){
	if(empty(trim($_POST['nama']))){
		$nama_err="Masukan nama lengkap Anda";
	}elseif(strlen($_POST['nama'])<3){
		$nama_err="Nama tidak boleh kurang dari 3 karakter";
	}elseif(ValidateName($_POST['nama'])){
		$nama_err="Format nama harus berupa karakter alphabet";
	}else{
		$nama=test_input($_POST['nama']);
		$nama=EscapeString($nama);
	}
	if(empty(trim($_POST['email']))){
		$email_err="Email tidak boleh kosong";
	}elseif(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
		$email_err="Format penulisan email salah";
	}else{
		if(CekEmail($_POST['email'])){
			$email_err="Email tersebut sudah digunakan !";
		}else{
			$email=test_input($_POST['email']);
			$email=EscapeString($email);
		}
	}
	if(empty(trim($_POST['username']))){
		$username_err="Username tidak boleh kosong";
	}elseif(strlen($_POST['username'])<3){
		$username_err="username tidak boleh kurang dari 3 karakater";
	}elseif(ValidateUsername($_POST['username'])){
		$username_err="Hanya kombinasi karakter angka dan huruf yang diperbolehkan";
	}
	else{

		if(CekUsername($_POST['username'])){
			$username_err="Maaf username tersebut sudah digunakan";
		}else{
			$username=test_input($_POST['username']);
			$username=EscapeString($username);
		}
	}
	if(empty(trim($_POST['password']))){
		$password_err="Masukan sebuah password";
	}elseif(strlen($_POST['password'])<6){
		$password_err="Password tidak boleh kurang dari 6 karakter";
	}else{
		$password=trim($_POST['password']);
	}
	if(empty(trim($_POST['konfir_password']))){
		$konfir_password_err="Masukan konfirmasi password";
	}else{
		$konfir_password=trim($_POST['konfir_password']);
		if(empty($password_err)&&($password !=$konfir_password)){
			$konfir_password_err="Konfirmasi password tidak cocok";
		}
	}
	if(strlen($virtual_account)!=16){
		$virtual_account_err="Terjadi kesalahan pada virtual account number. Silahkan coba refresh";
	}

	if(empty($nama_err)&& empty($email_err)&& empty($username_err)&& empty($password_err) && empty($konfir_password_err) && empty ($virtual_account_err)){

		if(BuatAkun($nama, $email, $username, $password)):
			//Menambahkan fungsi Insert Last ID
			//Semua data akan join ke tabel user dengan nilai parameter id_siswa dan id pada tabel user
			//ketika koneksi internet terputus, dan last_id tidak tereksekusi
			//maka ketika ada data baru yang ditambahkan dengan koneksi lancar
			//tidak akan mempengaruhi ke struktur data karena parameter data berdasarkan nilai id
			//pada tabel id user
			//id_siswa (last_id) merupakah id terakhir kali yang ditambahkan oleh user ke database
			//Dok : https://www.root93.co.id/2020/06/memahami-fungsi-php-mysql-last-insert-id.html
			$last_id = $koneksi->insert_id;	
			BuatAkunInsertIdMhs($last_id, $nama, $kode_daftar, $tgl_pendaftaran); 
			BuatAkunInsertIdOrtu($last_id);
			BuatAkunInsertIdDokumen($last_id); 
			BuatAkunInsertIdAsalSekolah($last_id); 
			BuatAkunInsertIdRaport($last_id); 
			BuatAkunInsertIdUn($last_id); 
			BuatAkunInsertIdPembayaran($last_id, $nama, $kode_daftar, $virtual_account);

			$simpan="<div class='alert alert-success'>Akun berhasil ditambahkan. Silahkan login untuk melanjutkan</div>";
			echo "
			<meta http-equiv=\"refresh\"content=\"3;URL=login\"/>
			";

			
		else:
			$simpan="<div class='alert alert-danger'>Terjadi kesalahan. Silahkan ulangi kembali</div>";
		endif;
	}
}

?>
<div id="content" class="p-4 p-md-5 pt-5">
		<ol class="breadcrumb mt-4">
            <li class="breadcrumb-item">
                  <a href="home">Kembali</a>
            </li>
            <li class="breadcrumb-item active">Buat Akun</li>
        </ol>
         <div class="alert alert-dismissible alert-info">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            Silahkan buat sebuah akun baru untuk bisa login dan melanjutkan pendaftaran
        </div>
         <?php echo $simpan; ?>
		<form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
			<div class="form-group">
				<label>Nama : </label>
				<input class="text-input form-control" type="text" name="nama" id="nama" placeholder="Masukan nama lengkap" maxlength="30" minlength="3" required=""/>
				<span class="text-danger"><?php echo $nama_err; ?></span>  
			</div>
			<div class="form-group">
				<label>Email : </label>
				<input class="form-control" type="text" name="email" id="email" placeholder="Masukan email. Contoh : myroot593@gmail.com" maxlength="30" required=""/>  
				<span class="text-danger"><?php echo $email_err; ?></span>
			</div>
			<div class="form-group">
				<label>Username : </label>
				<input class="form-control" type="text" name="username" id="username" placeholder="Masukan username. Contoh:doni22" maxlength="30" minlength="3" required=""/>
				<span class="text-danger"><?php echo $username_err; ?></span>  
			</div>
			<div class="form-group">
				<label>Password : </label>
				<input class="form-control" type="password" name="password" id="password" placeholder="Masukan password minimal 6 digit " minlength="6" required=""/>
				<span class="text-danger"><?php echo $password_err; ?></span>  
			</div>
			<div class="form-group">
				<label>Konfirmasi Password : </label>
				<input class="form-control" type="password" name="konfir_password" id="konfir_password" placeholder="Masukan password minimal 6 digit " minlength="6" required=""/> 
				<span class="text-danger"><?php echo $konfir_password_err; ?></span> 
			</div>
			<div class="form-group">
			<button type="submit" name="daftar" id="daftar" class="btn btn-primary btn-md">Daftar</button>
			<span class="text-danger"><?php echo $virtual_account_err; ?></span> 
			</div>
		</form>
</div>
<?php 
footer();
?>