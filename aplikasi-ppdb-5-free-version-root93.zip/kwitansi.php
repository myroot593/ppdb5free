<?php
session_start();
require_once 'function/function.session.php';
require_once 'config/database.php';
require_once 'function/function.user.php';
require_once 'plugins/mpdf/mpdf.php';
  if(SessionUserCek()){
    header("location:login");
    }else{
    SessionActive();
    $id=$DSessionArray[0];
    $nama_akun=$DSessionArray[1];
    $email=$DSessionArray[2];
    $username=$DSessionArray[3];  
  }
  $dokumen='FORMULIR PENDAFTARAN'; 
  $mpdf=new mPDF('utf-8', array(210,135)); 
  ob_start(); 
      $DataMhs=DataSiswa($id);
      $row=$DataMhs->fetch_array();    
      $id=$row['id_siswa'];
      $nomor_pendaftaran=$row['nomor_pendaftaran']; 
      $no_ktp=$row['no_ktp'];
      $nama=$row['nama']; 
      $nisn=$row['nisn'];
      $tgl=$row['tgl_pembayaran'];
      $ver=$row['verifikator_pembayaran'];
      $status_pembayaran=$row['status_pembayaran'];
      $kode_refrensi=$row['kode_refrensi'];

      $setting_pembayaran=PengaturanPembayaran();
      $pe_bayar=$setting_pembayaran->fetch_array();
      $setting_pembayaran->free_result();
      $DataMhs->free_result();

      if(empty($nomor_pendaftaran)):
        echo "<meta http-equiv=\"refresh\"content=\"3;URL=home\"/>";
        die('Silahkan isi dan lengkap data pribadi terlebih dahulu');
        exit(0);
      endif;
      
      GlobalDataSitus();
      if($status_pembayaran!=='Lunas'):
        die("Error");
      endif;
          
echo '

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<style>
  body {font-family: sans-serif;
    font-size: 9pt;
    background: transparent url(\'bgbarcode.png\') repeat-y scroll left top;
  }

  h5, p { margin: 0pt;
  }
  table.items {
    font-size: 9pt; 
    border-collapse: collapse;
    
  }
  td { vertical-align: top; 
  }
  table thead td { background-color: #EEEEEE;
    text-align: center;
  }
  table tfoot td { background-color: #AAFFEE;
    text-align: center;
  }
  .barcode {
    padding: 1.5mm;
    margin: 0;
    vertical-align: top;
    color: #000000;
  }
  .barcodecell {
    text-align: center;
    vertical-align: middle;
    padding: 0;
  }
  .kapital{
    text-transform:uppercase;
  }
  
</style>
</head>
<body>

<table class="items" width="100%" cellpadding="3">
  <tbody>
      <tr>
        <td align="right" style="border-bottom:3px solid #403d3d;">
          <img src="assets/img/'.$GlobalDataSitus[7].'" width="80" height="80"/>
            
        </td>
        <td align="center" colspan="2" style="border-bottom:3px solid #403d3d;">
         <h2>'.$GlobalDataSitus[0].'</h2>
         <p>'.$GlobalDataSitus[1].'</p>
    
        </td>
      </tr>
  </tbody>
</table>
<br>
<table class="items" width="100%" cellpadding="6">
  <tbody>
  
      <tr>
        <td colspan="4"  align="center"><h3>BUKTI PEMBAYARAN</h3></td>
          
      </tr>
      <tr>
        <td colspan="4">Sudah terima dari Biaya Administrasi PPDB '.$GlobalDataSitus[0].' atas nama :</td>
      </tr>

      <tr>
        <td>Nama</td>
        <td class="kapital">:  '.$nama.'</td> 
        <td>&nbsp;</td>    
      </tr>
      <tr>
        <td>No. Registrasi </td>
        <td>:  '.$nomor_pendaftaran.'/PPDB/'.date('Y').'</td>
        <td>&nbsp;</td>      
      </tr>
      <tr>
        <td>Nominal </td>
        <td>: Rp.'.$pe_bayar['jumlah_pembayaran'].'.'.$kode_refrensi.' </td>
        <td>&nbsp;</td>      
      </tr>
     
     
     
     
  </tbody>
</table>
<br>
 
<table style="border-top:3px dashed #ccc; width: 700px; margin-bottom: 15px;">
    <tr>
      <td colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td>Status Pembayaran [ ok ] Lunas [ ] Belum</td>
      <td>&nbsp;</td>
      <td>Tanggal pembayaran : </td>
      <td>&nbsp;</td>
      <td>'.$tgl.'</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Bendahara</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>'.$ver.'</td>
    </tr>
</table>
   
</body>
</html>
';

$html = ob_get_contents(); 
ob_end_clean();
$mpdf->WriteHTML($stylesheet,1);
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($dokumen.".pdf" ,'I');
exit;
?>
