<?php
    session_start();
    require_once '../core/session.php';
    require_once '../../config/database.php';    
    require_once '../core/function.php';
    if(BendaharaCek()):
        die("error");
    else:
        UserAktif(); 
        $admin_uid=$DataUser[0];
        $admin_username=$DataUser[1];
        $admin_email=$DataUser[2];
        $admin_nama=$DataUser[3];
        $admin_role=$DataUser[4];
        $admin_foto=$DataUser[5]; 
       
    endif;
    $AdminData=AdminData($admin_uid);
    $Admin_row=$AdminData->fetch_array();
    $AdminData->free_result();
   
?>

<?php
head_Bendahara();
css();
Menu_Bendahara();


?>

<?php if(!isset($_GET['page'])){$_GET['page']='';}?>

<?php if($_GET['page']=='dashboard'){ ?>
            <?php 
                $Dashboard=Dashboard();
                $DashboardData=$Dashboard->fetch_array();
                $JumlahGender=JumlahGender($DashboardData['jml_pria'], $DashboardData['jml_wanita']);    
                $PersentasePria=NilaiPersen($DashboardData['jml_pria'], $JumlahGender);
                $PersentaseWanita=NilaiPersen($DashboardData['jml_wanita'], $JumlahGender);               
               
            ?>
          
            <!-- END BREADCRUMB-->

             <!-- STATISTIC-->
            <section class="statistic">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        
                        <div class="recent-report3 m-b-40">
                            <div class="title-wrap">
                                    <h2 class="title-2">overview</h2>
                                    
                                </div>
                          <div class="row m-t-25">
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo JumlahPendaftar(); ?></h2>
                                                <span>Pendaftar</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c2">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_verifikasi']; ?></h2>
                                                <span>Belum Diverifikasi</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c3">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_diterima']; ?></h2>
                                                <span>Diterima</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c4">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_ditolak']; ?></h2>
                                                <span>Ditolak</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart4"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- END STATISTIC-->
        
         <?php Pembayaran_Bendahara(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar'){ ?>

         <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
         }else{
            LoadDataPendaftar();
         } 

         ?>
<?php }elseif($_GET['page']=='verifikasi-pembayaran'){ ?>
   
     <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert au-alert-danger alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
            }else{
                LoadVerifikasiPembayaran_Bendahara();
            }
        ?>  
<?php }elseif($_GET['page']=='logout'){ ?>
     <div class="main-content">
        <div class="section__content section__content--p30">
         <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">                                   
                        <div class="card-body">                                      
                            <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">                                                
                            Anda berhasil logout.
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true">×</span>
                             </button>
                            </div>                                        
                                       
                         </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        <?php UnsetDataUser(); ?>
<?php }else{ ?>
	<?php echo "
	<meta http-equiv=\"refresh\"content=\"0;URL=index.php?page=dashboard\" />
	";
	?>
<?php } ?>

<?php
footer();
?>
<script>
var ctx = document.getElementById("percent-chart93");
    if (ctx) {
      ctx.height = 280;
      var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          datasets: [
            {
              label: "My First dataset",
              data: [<?php echo $DashboardData['jml_pria']; ?>,<?php echo $DashboardData['jml_wanita']; ?>],
              backgroundColor: [
                '#00b5e9',
                '#fa4251'
              ],
              hoverBackgroundColor: [
                '#00b5e9',
                '#fa4251'
              ],
              borderWidth: [
                0, 0
              ],
              hoverBorderColor: [
                'transparent',
                'transparent'
              ]
            }
          ],
          labels: [
            'Pria',
            'Wanita'
          ]
        },
        options: {
          maintainAspectRatio: false,
          responsive: true,
          cutoutPercentage: 55,
          animation: {
            animateScale: true,
            animateRotate: true
          },
          legend: {
            display: false
          },
          tooltips: {
            titleFontFamily: "Poppins",
            xPadding: 15,
            yPadding: 10,
            caretPadding: 0,
            bodyFontSize: 16
          }
        }
      });
    }
</script>