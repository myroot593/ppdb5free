<?php
    session_start();
    require_once '../core/session.php';
    require_once '../../config/database.php';    
    require_once '../core/function.php';
    if(VerifikatorCek()):
        die("error");
    else:
        UserAktif(); 
        $admin_uid=$DataUser[0];
        $admin_username=$DataUser[1];
        $admin_email=$DataUser[2];
        $admin_nama=$DataUser[3];
        $admin_role=$DataUser[4];
        $admin_foto=$DataUser[5]; 
       
    endif;
    $AdminData=AdminData($admin_uid);
    $Admin_row=$AdminData->fetch_array();
    $AdminData->free_result();
?>

<?php
Head_Verifikator();
css();
Menu_Verifikator();
Head_MenuVerifikator();

?>

<?php if(!isset($_GET['page'])){$_GET['page']='';}?>

<?php if($_GET['page']=='dashboard'){ ?>
            <?php 
                $Dashboard=Dashboard();
                $DashboardData=$Dashboard->fetch_array();
                $JumlahGender=JumlahGender($DashboardData['jml_pria'], $DashboardData['jml_wanita']);    
                $PersentasePria=NilaiPersen($DashboardData['jml_pria'], $JumlahGender);
                $PersentaseWanita=NilaiPersen($DashboardData['jml_wanita'], $JumlahGender);               
               
            ?>
            

             <!-- STATISTIC-->
            <section class="statistic m-t-75">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                                               <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">overview</h2>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-25">
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo JumlahPendaftar(); ?></h2>
                                                <span>Pendaftar</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c2">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_verifikasi']; ?></h2>
                                                <span>Belum Diverifikasi</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c3">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_diterima']; ?></h2>
                                                <span>Diterima</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c4">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                <h2><?php echo $DashboardData['jml_ditolak']; ?></h2>
                                                <span>Ditolak</span>
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart4"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END STATISTIC-->
            <section>
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-6">
                                <!-- RECENT REPORT 2-->
                                <div class="au-card chart-percent-card">
                                    <div class="au-card-inner">
                                        <h5 class="title-2 tm-b-5">Presentase</h5>
                                        <em class="small">Presentase pendaftar berdasarkan jenis kelamin</em>
                                        <div class="row no-gutters">
                                            <div class="col-xl-6">
                                                <div class="chart-note-wrap">
                                                    <div class="chart-note mr-0 d-block">
                                                        <span class="dot dot--blue"></span>
                                                        <span>pria <?php echo $PersentasePria; ?></span>
                                                    </div>
                                                    <div class="chart-note mr-0 d-block">
                                                        <span class="dot dot--red"></span>
                                                        <span>wanita <?php echo $PersentaseWanita; ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="percent-chart">
                                                    <canvas id="percent-chart93"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="top-campaign">
                                    <h3 class="title-3 m-b-30">data masuk</h3>
                                       <em class="small">Data masuk terakhir yang belum diverifikasi</em>
                                       <div class="table-responsive">
                                         <?php 
                                             $DataMasuk=DataMasuk();
                                             $row=$DataMasuk->fetch_array();
                                                $id_p=$row['id'];
                                                $nama_p=$row['nama'];
                                                $nomor_pendaftaran_p=$row['nomor_pendaftaran'];
                                                $status_pendaftaran_p=$row['status_pendaftaran'];
                                           
                                             $DataMasuk->free_result();   
                                        ?> 
                                         <table class="table">
                                            <tr>
                                                <td>No. Pendft</td>
                                                <td><?php echo $nomor_pendaftaran_p; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Nama</td>
                                                <td><?php echo $nama_p; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Status Pendaft</td>
                                                <td><?php echo $status_pendaftaran_p; ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><a href=?page=verifikasi-data&id=<?php echo $id_p;?>>Verifikasi</td>
                                                
                                            </tr>
                                        </table>   
                                       </div>
                                       
                                       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                                <!-- END RECENT REPORT 2             -->
<?php }elseif($_GET['page']=='informasi'){ ?>
   
            <?php LoadInformasi(); ?>
<?php }elseif($_GET['page']=='informasi-tambah'){ ?>
     
        <?php LoadInformasiTambah(); ?>    
<?php }elseif($_GET['page']=='informasi-edit'){ ?>
 
        <?php
            if(!LoadInformasiEdit(trim($_GET['id']))){
                echo'
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>

                ';

            }else{
                LoadInformasiUpdate();
            }

        ?>  
<?php }elseif($_GET['page']=='informasi-delete'){ ?>
    <?php
            if(!LoadInformasiEdit(trim($_GET['id']))){
                echo'
                <div class="container-fluid">
                <div class="container-fluid mt-4">
                    <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
                </div>
                </div>
                ';

            }else{
                
                Load_DeleteInfo();
                
            }

        ?>  
<?php }elseif($_GET['page']=='data-pendaftar-semua'){ ?> 
           
         <?php Pendaftar(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar-bverifikasi'){ ?>
  
         <?php PendaftarBelumVerifikasi(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar-terverifikasi'){ ?>
   
         <?php PendaftarTerverifikasi(); ?>  
<?php }elseif($_GET['page']=='data-pendaftar-diterima'){ ?>
       
         <?php PendaftarDiterima(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar-ditolak'){ ?>
   
         <?php PendaftarDitolak(); ?> 
<?php }elseif($_GET['page']=='data-pendaftar'){ ?>
        
         <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
         }else{
            LoadDataPendaftar();
         } 

         ?>
<?php }elseif($_GET['page']=='pembayaran'){ ?>
      
         <?php Pembayaran(); ?> 
<?php }elseif($_GET['page']=='verifikasi-data'){ ?>
     
        <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
            }else{
                LoadVerifikasiPendaftar();
            }
        ?>  
<?php }elseif($_GET['page']=='verifikasi-pembayaran'){ ?>
   
     <?php if(!DataPendaftarDetail($_GET['id'])){
            echo '
             <div class="container-fluid mt-4">
                <div class="alert au-alert-danger alert-dismissible fade show au-alert au-alert--70per" role="alert">
                        <i class="zmdi zmdi-close-circle"></i>
                        <span class="content">Data tidak ditemukan.</span>
                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="zmdi zmdi-close-circle"></i>
                            </span>
                        </button>
                    </div>
            </div>
            ';
            }else{
                LoadVerifikasiPembayaran();
            }
        ?>  
<?php }elseif($_GET['page']=='jalur-daftar'){ ?>
   
    <?php LoadJalur_Daftar(); ?>
<?php }elseif($_GET['page']=='jalur-delete'){ ?>
   
    <?php
    if(DeleteJalur(trim($_GET['id']))):
          $simpan='
                      
                        <div class="container-fluid mt-4">                            
                            <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                    <i class="zmdi zmdi-check-circle"></i>
                                    <span class="content">Data berhasil dihapus</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>';
                         echo " <meta http-equiv=\"refresh\"content=\"1;URL=?page=jalur-daftar\" />
                        ";
                       
                
            else:
                $simpan='<div class="container-fluid mt-4">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="zmdi zmdi-close-circle"></i>
                                    <span class="content">Data gagal dihapus.</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>
                ';
    endif;
    echo $simpan;
    ?>

<?php }elseif($_GET['page']=='jurusan'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Jurusan</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php Load_Jurusan(); ?>
<?php }elseif($_GET['page']=='jurusan-delete'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Delete jurusan</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php
    if(DeleteJurusan(trim($_GET['id']))):
          $simpan='
                      
                        <div class="container-fluid mt-4">                            
                            <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                    <i class="zmdi zmdi-check-circle"></i>
                                    <span class="content">Data berhasil dihapus</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>';
                         echo " <meta http-equiv=\"refresh\"content=\"3;URL=?page=jurusan\" />
                        ";
                       
                
            else:
                $simpan='<div class="container-fluid mt-4">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="zmdi zmdi-close-circle"></i>
                                    <span class="content">Data gagal dihapus.</span>
                                    <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">
                                            <i class="zmdi zmdi-close-circle"></i>
                                        </span>
                                    </button>
                                </div>
                        </div>
                ';
    endif;
    echo $simpan;
    ?>
<?php }elseif($_GET['page']=='kelas'){ ?>
    <section class="au-breadcrumb m-t-75">
                        <div class="section__content section__content--p30">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="au-breadcrumb-content">
                                            <div class="au-breadcrumb-left">
                                                <span class="au-breadcrumb-span">You are here:</span>
                                                <ul class="list-unstyled list-inline au-breadcrumb__list">
                                                    <li class="list-inline-item active">
                                                        <a href="?page=dashboard">Home</a>
                                                    </li>
                                                    <li class="list-inline-item seprate">
                                                        <span>/</span>
                                                    </li>
                                                    <li class="list-inline-item">Kelas</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
    </section>
    <?php Load_Kelas(); ?>
<?php }elseif($_GET['page']=='kelas-delete'){ ?>
<?php }elseif($_GET['page']=='account'){ ?>
    <?php  
     $password_err = $confir_password_err = $simpan = "";
       if(isset($_POST['update_verifikator'])){
            if(empty(trim($_POST['password']))){
                $password_err="Password tidak boleh kosong";
            }elseif(strlen($_POST['password'])<6){
                $password_err="Password tidak boleh kurang dari 6 karakater";
            }else{
                $password=trim($_POST['password']);
            }
            if(empty(trim($_POST['confir_password']))){
                $confir_password_err="Konfirmasi passwird tidak boleh kosong";
            }else{
                $confir_password=trim($_POST['confir_password']);
                if(empty($password_err)&& ($password!=$confir_password)){
                    $confir_password_err="Konfirmasi password tidak cocok";
                }
            }
            

            if(empty($password_err) && empty($confir_password_err)){
                if(UpdateVerifikator($password, $admin_uid)):
                    
                        
                    $simpan='
                           
                            <div class="container-fluid mt-4">                            
                                <div class="alert au-alert-success alert-dismissible fade show au-alert au-alert--70per" role="alert">
                                        <i class="zmdi zmdi-check-circle"></i>
                                        <span class="content">Data berhasil diperbaharui</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>';
                            
                     echo "
                     <meta http-equiv=\"refresh\"content=\"2;URL=?page=account\" />
                     ";      
                    
                else:
                    $simpan='<div class="container-fluid mt-4">
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <i class="zmdi zmdi-close-circle"></i>
                                        <span class="content">Data gagal disimpan.</span>
                                        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">
                                                <i class="zmdi zmdi-close-circle"></i>
                                            </span>
                                        </button>
                                    </div>
                            </div>
                    ';

                endif;
                
            }
        }

    ?>

  
     <?php echo $simpan; ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                  
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                                <div class="card-body">    
                                                                                                
                                           <div class="card-title">
                                                <h3 class="text-center title-2">Account</h3>
                                            </div>

                                            <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <label for="username" class="control-label mb-1">Username</label>
                                                    <fieldset disabled>
                                                        <input class="form-control" type="text" id="username" name="username" value="<?php echo $admin_username; ?>" required="" placeholder="Masukan username untuk panitia">
                                                    </fieldset>                
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="password" class="control-label mb-1">Password</label>  
                                                            <input class="form-control" type="password" id="password" name="password" required="" placeholder="Masukan password">
                                                            <span class="text-danger"><?php echo $password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group">
                                                            <label for="confir_password" class="control-label mb-1">Konfirmasi Password</label>  
                                                            <input class="form-control" type="password" id="confir_password" name="confir_password" required="" placeholder="Konfirmasi password">
                                                            <span class="text-danger"><?php echo $confir_password_err; ?></span>               
                                                        </div> 
                                                    </div>
                                                </div>                                
                                                 <div class="form-group">
                                                    <label for="email" class="control-label mb-1">E-mail</label> 
                                                    <fieldset disabled> 
                                                         <input class="form-control" type="text" id="email" name="email" value="<?php echo $admin_email; ?>" required="" placeholder="Masukan email">
                                                    </fieldset>               
                                                </div> 
                                                 <div class="form-group">
                                                    <label for="nama" class="control-label mb-1">Nama Lengkap</label> 
                                                     <fieldset disabled> 
                                                        <input class="form-control" type="text" id="nama" name="nama" value="<?php echo $admin_nama; ?>" required="" placeholder="Masukan nama lengkap panitia">
                                                    </fieldset>              
                                                </div>                                                    
                                                
                                                                           
                                                <div class="form-group">
                                                    <button id="update_verifikator" name="update_verifikator" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fas fa-user-circle"></i>&nbsp;
                                                    <span id="update_verifikator">Simpan</span>
                                                    <span id="update_verifikator" style="display:none;">Sending…</span>
                                                    </button>
                                                </div>
                                            </form>

                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
<?php }elseif($_GET['page']=='logout'){ ?>
     <div class="main-content">
        <div class="section__content section__content--p30">
         <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                                   
                                    <div class="card-body">                                      
                                      <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
                                                
                                        Anda berhasil logout.
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                        </div>                                           
                                       
                                    </div>
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        <?php UnsetDataUser(); ?>
<?php }else{ ?>
    <?php echo "
    <meta http-equiv=\"refresh\"content=\"0;URL=index.php?page=dashboard\" />
    ";
    ?>
<?php } ?>

<?php
footer();
?>
<script>
var ctx = document.getElementById("percent-chart93");
    if (ctx) {
      ctx.height = 280;
      var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
          datasets: [
            {
              label: "My First dataset",
              data: [<?php echo $DashboardData['jml_pria']; ?>,<?php echo $DashboardData['jml_wanita']; ?>],
              backgroundColor: [
                '#00b5e9',
                '#fa4251'
              ],
              hoverBackgroundColor: [
                '#00b5e9',
                '#fa4251'
              ],
              borderWidth: [
                0, 0
              ],
              hoverBorderColor: [
                'transparent',
                'transparent'
              ]
            }
          ],
          labels: [
            'Pria',
            'Wanita'
          ]
        },
        options: {
          maintainAspectRatio: false,
          responsive: true,
          cutoutPercentage: 55,
          animation: {
            animateScale: true,
            animateRotate: true
          },
          legend: {
            display: false
          },
          tooltips: {
            titleFontFamily: "Poppins",
            xPadding: 15,
            yPadding: 10,
            caretPadding: 0,
            bodyFontSize: 16
          }
        }
      });
    }
</script>