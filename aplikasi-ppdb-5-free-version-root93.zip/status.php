<?php
session_start();
require_once 'function/function.session.php';
require_once 'config/database.php';
require_once 'function/function.user.php';
require_once 'plugins/mpdf/mpdf.php';
  if(SessionUserCek()){
    header("location:login");
    }else{
    SessionActive();
    $id=$DSessionArray[0];
    $nama_akun=$DSessionArray[1];
    $email=$DSessionArray[2];
    $username=$DSessionArray[3];  
  }
  $dokumen='FORMULIR PENDAFTARAN'; 
  $mpdf=new mPDF('utf-8', 'A4'); 
  ob_start(); 
      $DataSiswa=DataSiswa($id);   
      $row=$DataSiswa->fetch_array();
      $id=$row['id'];
      $nomor_pendaftaran=$row['nomor_pendaftaran'];
      $nisn=$row['nisn'];
      $nama=$row['nama'];
      $asal_sekolah=$row['asal_sekolah']; 
      $nama_sekolah=$row['nama_sekolah'];
      $foto=$row['foto'];
      $jalur_pendaftaran=$row['jalur_pendaftaran'];
      $status_pendaftaran=$row['status_pendaftaran'];
      $ipa_1=$row['ipa_1'];
      $matematika_1=$row['matematika_1'];
      $indonesia_1=$row['indonesia_1'];
      $inggris_1=$row['inggris_1'];

      $ipa_2=$row['ipa_2'];
      $matematika_2=$row['matematika_2'];
      $indonesia_2=$row['indonesia_2'];
      $inggris_2=$row['inggris_2'];

      $ipa_3=$row['ipa_3'];
      $matematika_3=$row['matematika_3'];
      $indonesia_3=$row['indonesia_3'];
      $inggris_3=$row['inggris_3'];

      $ipa_4=$row['ipa_4'];
      $matematika_4=$row['matematika_4'];
      $indonesia_4=$row['indonesia_4'];
      $inggris_4=$row['inggris_4'];

      $ipa_5=$row['ipa_5'];
      $matematika_5=$row['matematika_5'];
      $indonesia_5=$row['indonesia_5'];
      $inggris_5=$row['inggris_5'];
      //nilai Un
      $ipa=$row['ipa'];
      $matematika=$row['matematika'];
      $bahasa_indonesia=$row['bahasa_indonesia'];
      $bahasa_inggris=$row['bahasa_inggris'];

      
      $DataSiswa->free_result();
      $jadwal=Tampil_JadwalTest();
      $jadwal_test=$jadwal->fetch_array();
      $tanggal_test=$jadwal_test['tanggal_test'];
      $waktu_test=$jadwal_test['waktu_test'];
      $materi=$jadwal_test['materi'];
      $jadwal->free_result();  
      
      $tahun_sekarang=date('Y');
      $tahun_selanjutnya=$tahun_sekarang+1;
      $bulan_sekarang=date('m');

      $d1=NilaiRaport($ipa_1, $matematika_1, $indonesia_1, $inggris_1);
      $d2=NilaiRaport($ipa_2, $matematika_2, $indonesia_2, $inggris_2);
      $d3=NilaiRaport($ipa_3, $matematika_3, $indonesia_3, $inggris_3);
      $d4=NilaiRaport($ipa_4, $matematika_4, $indonesia_4, $inggris_4);
      $d5=NilaiRaport($ipa_5, $matematika_5, $indonesia_5, $inggris_5);

      if($status_pendaftaran!='Diterima'){
        die("Error : Anda belum diterima, belum bisa cetak bukti");
      }
      if(empty($nomor_pendaftaran)):
        die("Error : Registration Number Not Found ! Please Complete your Registration");
      endif;
      if(empty($tanggal_lahir)):
           //explode tgl lahir
        $tgl=NULL; 
      else:
        $tgl=explode("-", $tanggal_lahir); 
      endif; 
      GlobalDataSitus();
          
echo '

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<style>
  body {font-family: sans-serif;
    font-size: 10pt;
    background: transparent url(\'bgbarcode.png\') repeat-y scroll left top;
  }

  h5, p { margin: 5pt;
  }
  table.items {
    font-size: 10pt; 
    border-collapse: collapse;
    
  }
  td { vertical-align: top; 
  }
  table thead td { background-color: #EEEEEE;
    text-align: center;
  }
  table tfoot td { background-color: #AAFFEE;
    text-align: center;
  }
  .barcode {
    padding: 1.5mm;
    margin: 0;
    vertical-align: top;
    color: #000000;
  }
  .barcodecell {
    text-align: center;
    vertical-align: middle;
    padding: 0;
  }
  .border-uni{
    border-bottom:1px solid #403d3d;
    border-left:1px solid #403d3d;
    
  }
  .border-center{
    border-bottom:1px solid #403d3d;

  }
  .border-center-right{
    border-bottom:1px solid #403d3d;
    border-right:1px solid #403d3d;
  }

  
</style>
</head>
<body>
<table class="items" width="100%" cellpadding="2">
  <tbody>
      <tr>
        <td align="right" style="border-bottom:3px solid #403d3d;">
          <img src="assets/img/'.$GlobalDataSitus[7].'" width="90" height="90"/>
            
        </td>
        <td align="center" colspan="2" style="border-bottom:3px solid #403d3d;">
         <h2>'.$GlobalDataSitus[0].'</h2>
         <p>'.$GlobalDataSitus[1].'</p>
    
        </td>
      </tr>
  </tbody>
</table>
<br>
<table class="items" width="100%">
  <tr>
    <td align="center"><h4 style="text-decoration: underline;">SURAT KETERANGAN DITERIMA</h4></td>
  </tr>
  <tr>
    <td align="center">Nomor : 423.7 / '.$bulan_sekarang.' / '.$tahun_sekarang.'</td>
  </tr>
</table>
<p>Berdasarkan Hasil Seleksi Penerimaan Peserta Didik Baru (PPDB)'.$GlobalDataSitus[0].' Tahun Pelajaran '.$tahun_sekarang. '/ '.$tahun_selanjutnya.',  maka dengan ini menerangkan bahwa :</p>
<br>
<table class="items" width="100%" border="1" cellpadding="4"> 
 
  <tr>
    <td>NAMA</td>
    <td style="text-transform:uppercase;">'.$nama.'</td>
  </tr>
   <tr>
    <td>NISN </td>
    <td>'.$nisn.'</td>
  </tr>
  <tr>
    <td>SEKOLAH ASAL</td>  
    <td style="text-transform:uppercase;"> '.$nama_sekolah.'</td>
  </tr>
  <tr>
    <td>Rata - rata Nilai Semester </td>
    <td>'.Nilai_Rata_Raport($d1,$d2,$d3,$d4,$d5).'</td>
  </tr>
</table>
<h1 align="center" style="text-transform:uppercase;">'.$status_pendaftaran.'<br>
</h1>
<table style="border-top:3px dashed #ccc; width: 700px; margin-bottom: 15px;">
    <tr>
      <td colspan="5">&nbsp;</td>
    </tr>
    <tr>
      <td>Hasil Verifikasi [ ] Lulus [ ] Tidak</td>
      <td>&nbsp;</td>
      <td>Tanggal verifikasi : </td>
      <td>&nbsp;</td>
      <td>Tanggal Verifikasi Online: </td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Petugas Verifikator Berkas </td>
      <td>&nbsp;</td>
      <td>Petugas Verifikator Online</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>Nama</td>
      <td>&nbsp;</td>
      <td>Nama</td>
    </tr>
</table>
</body>
</html>
';

$html = ob_get_contents(); 
ob_end_clean();
$mpdf->WriteHTML($stylesheet,1);
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($dokumen.".pdf" ,'I');
exit;
?>
